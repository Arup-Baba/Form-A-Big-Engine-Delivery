
import React from 'react';
import { Service, ServiceSelection, CategorizedAddon } from '../types';
import { ADDON_PRICES, ADDON_CATEGORIES } from '../constants';
import { IconPlus, IconMinus, IconTrash } from './ui/Icon';
import Button from './ui/Button';
import Input from './ui/Input';

interface Props {
  state: Service;
  updateField: <K extends keyof Service>(field: K, value: Service[K]) => void;
  dispatch: React.Dispatch<any>;
  googleDriveUploadUrl?: string;
}

const AddonItem: React.FC<{
    label: string;
    price: number;
    value: number;
    onChange: (val: number) => void;
}> = ({ label, price, value, onChange }) => (
    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-200">
        <div>
            <p className="font-semibold text-slate-800">{label}</p>
            <p className="text-sm text-slate-500">₹{price.toFixed(2)}</p>
        </div>
        <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={() => onChange(Math.max(0, value - 1))} className="p-1 h-8 w-8" aria-label={`Decrease ${label} quantity`}>
              <IconMinus className="w-4 h-4" />
            </Button>
            <span className="text-base font-semibold w-8 text-center" aria-live="polite">{value}</span>
            <Button variant="ghost" size="sm" onClick={() => onChange(value + 1)} className="p-1 h-8 w-8" aria-label={`Increase ${label} quantity`}>
              <IconPlus className="w-4 h-4" />
            </Button>
        </div>
    </div>
);


const AddonsStep: React.FC<Props> = ({ state, updateField, dispatch }) => {
  const addons = [
    { key: 'standardWashQty', label: 'Standard Wash', price: ADDON_PRICES.standardWash },
    { key: 'interiorCleaningQty', label: 'Interior Cleaning', price: ADDON_PRICES.interiorCleaning },
    { key: 'premiumWashQty', label: 'Premium Wash', price: ADDON_PRICES.premiumWash },
    { key: 'waxServiceQty', label: 'Wax Service', price: ADDON_PRICES.waxService },
    { key: 'engineDetailingQty', label: 'Engine Detailing', price: ADDON_PRICES.engineDetailing },
    { key: 'wheelBalancingQty', label: 'Wheel Balancing', price: ADDON_PRICES.wheelBalancing },
  ];

  const handleAddCategorizedAddon = () => {
    dispatch({ type: 'ADD_CATEGORIZED_ADDON' });
  };

  const handleRemoveCategorizedAddon = (index: number) => {
    dispatch({ type: 'REMOVE_CATEGORIZED_ADDON', index });
  };
  
  const handleUpdateCategorizedAddon = (index: number, field: keyof CategorizedAddon, value: any) => {
    dispatch({ type: 'UPDATE_CATEGORIZED_ADDON', index, field, value });
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Pre-defined Add-ons</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {addons.map(addon => (
                <AddonItem
                    key={addon.key}
                    label={addon.label}
                    price={addon.price}
                    value={state[addon.key as keyof Service] as number}
                    onChange={(v) => updateField(addon.key as keyof Service, v)}
                />
            ))}
        </div>
      </div>

      <div className="pt-8 border-t border-slate-200">
         <h3 className="text-lg font-semibold text-slate-800 mb-4">Custom Add-on Products</h3>
         <div className="space-y-4">
            {state.categorizedAddons.map((addon, index) => (
                <div key={addon.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-4">
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                       <div>
                            <label htmlFor={`addon-cat-${index}`} className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                            <select
                                id={`addon-cat-${index}`}
                                value={addon.category}
                                onChange={(e) => handleUpdateCategorizedAddon(index, 'category', e.target.value)}
                                className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                            >
                                {ADDON_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                       </div>
                       <Input 
                            label="Product Name"
                            id={`addon-name-${index}`}
                            value={addon.productName}
                            onChange={(e) => handleUpdateCategorizedAddon(index, 'productName', e.target.value)}
                        />
                         <Input 
                            label="Quantity"
                            id={`addon-qty-${index}`}
                            type="number"
                            value={addon.quantity}
                            onChange={(e) => handleUpdateCategorizedAddon(index, 'quantity', parseInt(e.target.value) || 0)}
                        />
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                        <Input 
                            label="Value (INR)"
                            id={`addon-amount-${index}`}
                            type="number"
                            value={addon.amount}
                            onChange={(e) => handleUpdateCategorizedAddon(index, 'amount', parseFloat(e.target.value) || 0)}
                        />
                        <div className="md:col-span-2 flex justify-between items-end">
                            <p className="font-semibold text-slate-700">
                                Sub-total: ₹{(addon.quantity * addon.amount).toFixed(2)}
                            </p>
                            <Button variant="danger" size="sm" onClick={() => handleRemoveCategorizedAddon(index)} className="p-2 h-10 w-10" aria-label={`Remove ${addon.productName || 'product'}`}>
                                <IconTrash className="w-5 h-5" />
                            </Button>
                        </div>
                   </div>
                </div>
            ))}
             <div className="pt-2">
                <Button onClick={handleAddCategorizedAddon} variant="ghost">
                    <IconPlus className="w-5 h-5 mr-2" /> Add Product
                </Button>
            </div>
         </div>
      </div>

      <div className="mt-6 pt-6 border-t-2 border-slate-300 flex justify-end items-center">
          <span className="text-xl font-bold text-slate-800">Total Add-ons: ₹{state.addonsTotal.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default AddonsStep;
