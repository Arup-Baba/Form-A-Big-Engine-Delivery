
import React, { useState, useMemo } from 'react';
import { Service, ServiceSelection } from '../types';
import { useServiceForm } from '../hooks/useServiceForm';
import CustomerDetailsStep from './CustomerDetailsStep';
import ServiceSelectionStep from './ServiceSelectionStep';
import { ServiceDetailsStep } from './ServiceDetailsStep';
import AddonsStep from './AddonsStep';
import CustomServicesStep from './CustomServicesStep';
import { SummaryStep } from './SummaryStep';
import Stepper from './Stepper';
import Card from './ui/Card';
import Button from './ui/Button';

interface ServiceFormProps {
  initialService?: Service | null;
  onSubmit: (service: Service) => void;
  onSaveDraft: (service: Service) => void;
  onExit: () => void;
  googleDriveUploadUrl: string;
}

const ALL_STEPS = [
  { name: 'Customer Details', component: CustomerDetailsStep, isVisible: (state: Service) => true },
  { name: 'Service Selection', component: ServiceSelectionStep, isVisible: (state: Service) => true },
  { 
    name: 'Service Details', 
    component: ServiceDetailsStep, 
    isVisible: (state: Service) => 
      state.serviceSelection.some(s => 
        [ServiceSelection.CarWashing, ServiceSelection.TyreReplacement, ServiceSelection.BatteryReplacement].includes(s)
      )
  },
  { 
    name: 'Add-ons', 
    component: AddonsStep, 
    isVisible: (state: Service) => state.serviceSelection.includes(ServiceSelection.Addons)
  },
  { name: 'Custom Services', component: CustomServicesStep, isVisible: (state: Service) => true },
  { name: 'Invoice Summary', component: SummaryStep, isVisible: (state: Service) => true },
];

const ServiceForm: React.FC<ServiceFormProps> = ({ initialService, onSubmit, onSaveDraft, onExit, googleDriveUploadUrl }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const { state, dispatch, updateField } = useServiceForm(initialService);

  const visibleSteps = useMemo(() => {
    return ALL_STEPS.map((step, index) => ({...step, originalIndex: index}))
                     .filter(step => step.isVisible(state));
  }, [state]);

  const StepComponent = visibleSteps[currentStepIndex].component;

  const handleStepClick = (index: number) => {
    if (index < currentStepIndex) {
      setCurrentStepIndex(index);
    }
  };

  const nextStep = () => setCurrentStepIndex(prev => Math.min(prev + 1, visibleSteps.length - 1));
  const prevStep = () => setCurrentStepIndex(prev => Math.max(prev - 1, 0));

  const handleSaveDraft = () => {
    onSaveDraft(state);
  };
  
  const handleSubmit = () => {
    if (state.acknowledgement) {
      onSubmit(state);
    }
  };

  const isLastStep = currentStepIndex === visibleSteps.length - 1;

  return (
    <Card>
      <div className="mb-16 pb-4 border-b border-slate-200 no-print">
        <Stepper 
          steps={visibleSteps} 
          currentStepIndex={currentStepIndex} 
          onStepClick={handleStepClick} 
        />
      </div>

      <div className="min-h-[300px]">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">{visibleSteps[currentStepIndex].name}</h2>
        {isLastStep ? (
          <SummaryStep state={state} updateField={updateField} />
        ) : (
          <StepComponent state={state} updateField={updateField} dispatch={dispatch} googleDriveUploadUrl={googleDriveUploadUrl} />
        )}
      </div>

      <div className="mt-8 pt-6 border-t border-slate-200 flex justify-between items-center no-print">
        <div>
            {currentStepIndex > 0 && (
                <Button variant="secondary" onClick={prevStep}>Back</Button>
            )}
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={handleSaveDraft}>Save as Draft</Button>
          {!isLastStep ? (
            <Button onClick={nextStep}>Next</Button>
          ) : (
            <Button onClick={handleSubmit} disabled={!state.acknowledgement}>Submit</Button>
          )}
        </div>
      </div>
    </Card>
  );
};

export default ServiceForm;
