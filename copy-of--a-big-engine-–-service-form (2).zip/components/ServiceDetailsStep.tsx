
import React from 'react';
import { Service, ServiceSelection, TyreDetail, BatteryDetail } from '../types';
import Input from './ui/Input';
import QuantityInput from './ui/QuantityInput';
import FileUpload from './ui/FileUpload';

interface Props {
  state: Service;
  updateField: <K extends keyof Service>(field: K, value: Service[K]) => void;
  dispatch: React.Dispatch<any>;
  googleDriveUploadUrl: string;
}

export const ServiceDetailsStep: React.FC<Props> = ({ state, updateField, dispatch, googleDriveUploadUrl }) => {

  const handleUpdateTyreDetail = (index: number, field: keyof TyreDetail, value: any) => {
    dispatch({ type: 'UPDATE_TYRE_DETAIL', index, field, value });
  };
  
  const handleUpdateBatteryDetail = (index: number, field: keyof BatteryDetail, value: any) => {
    dispatch({ type: 'UPDATE_BATTERY_DETAIL', index, field, value });
  };

  return (
    <div className="space-y-8">
      {state.serviceSelection.includes(ServiceSelection.CarWashing) && (
        <div className="p-4 border border-slate-200 rounded-lg">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Car Washing Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start mb-6">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Quantity</label>
                  <QuantityInput value={state.carwashQuantity} onChange={(v) => updateField('carwashQuantity', v)} />
              </div>
              <div>
                  <Input
                      label="Price per Wash (₹)"
                      id="carWashPrice"
                      type="number"
                      value={state.carWashPrice}
                      onChange={(e) => updateField('carWashPrice', parseFloat(e.target.value) || 0)}
                  />
              </div>
              <div className="space-y-2 pt-2">
                  <label htmlFor="isSubscription" className="font-medium text-slate-700 flex items-center space-x-2 cursor-pointer">
                    <input
                        type="checkbox"
                        id="isSubscription"
                        checked={state.isSubscription}
                        onChange={(e) => updateField('isSubscription', e.target.checked)}
                        className="h-4 w-4 rounded border-gray-300 text-brand-accent focus:ring-brand-accent"
                    />
                    <span>Subscription Customer?</span>
                  </label>
                  <p className="text-lg font-semibold text-slate-700">Total: ₹{state.carwashTotalAmount.toFixed(2)}</p>
              </div>
          </div>
          <div className="space-y-4">
              <h4 className="font-semibold text-slate-700 mt-4 border-b pb-2">Before Media</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <FileUpload uploadType="photo" label="Before Washing Photo" fileUrl={state.beforeWashingPhoto} onUpload={(url) => updateField('beforeWashingPhoto', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Inventory & Dirtiness" fileUrl={state.beforeVideoInventory} onUpload={(url) => updateField('beforeVideoInventory', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Top Body" fileUrl={state.beforeVideoTopBody} onUpload={(url) => updateField('beforeVideoTopBody', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Underchassis" fileUrl={state.beforeVideoUnderchassis} onUpload={(url) => updateField('beforeVideoUnderchassis', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
              </div>
              <h4 className="font-semibold text-slate-700 mt-4 border-b pb-2">After Media</h4>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <FileUpload uploadType="photo" label="After Washing Photo" fileUrl={state.afterWashingPhoto} onUpload={(url) => updateField('afterWashingPhoto', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Interior" fileUrl={state.afterVideoInterior} onUpload={(url) => updateField('afterVideoInterior', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Exterior" fileUrl={state.afterVideoExterior} onUpload={(url) => updateField('afterVideoExterior', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
                <FileUpload uploadType="video" label="Underchassis" fileUrl={state.afterVideoUnderchassis} onUpload={(url) => updateField('afterVideoUnderchassis', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
              </div>
          </div>
        </div>
      )}

      {state.serviceSelection.includes(ServiceSelection.TyreReplacement) && (
        <div className="p-4 border border-slate-200 rounded-lg">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Tyre Replacement Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 items-start">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Quantity</label>
                  <QuantityInput value={state.tyreReplacementQuantity} onChange={(v) => updateField('tyreReplacementQuantity', v)} />
              </div>
              <div>
                <Input
                    label="Price per Tyre (₹)"
                    id="tyreReplacementPrice"
                    type="number"
                    value={state.tyreReplacementPrice}
                    onChange={(e) => updateField('tyreReplacementPrice', parseFloat(e.target.value) || 0)}
                />
              </div>
              <div className="self-end pb-2">
                <p className="text-lg font-semibold text-slate-700">Total: ₹{state.tyreReplacementTotalAmount.toFixed(2)}</p>
              </div>
          </div>
          <div className="space-y-4">
          {state.tyreDetails.map((tyre, index) => (
             <div key={tyre.tyreId} className="p-4 bg-slate-50 rounded-lg border space-y-4">
                <h4 className="font-semibold text-slate-700">Tyre {index + 1}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input label="DOT Code" id={`tyre-dot-${index}`} value={tyre.dotCode} onChange={e => handleUpdateTyreDetail(index, 'dotCode', e.target.value)} />
                    <Input label="Tyre Size" id={`tyre-size-${index}`} value={tyre.tyreSize} onChange={e => handleUpdateTyreDetail(index, 'tyreSize', e.target.value)} />
                    <Input label="Brand" id={`tyre-brand-${index}`} value={tyre.brand} onChange={e => handleUpdateTyreDetail(index, 'brand', e.target.value)} />
                    <Input label="Model" id={`tyre-model-${index}`} value={tyre.model} onChange={e => handleUpdateTyreDetail(index, 'model', e.target.value)} />
                </div>
                <FileUpload uploadType="photo" label="DOT Serial Number Image" fileUrl={tyre.dotSerialNumberImage} onUpload={(url) => handleUpdateTyreDetail(index, 'dotSerialNumberImage', url)} carNumber={state.carNumber} uploadUrl={googleDriveUploadUrl} />
             </div>
          ))}
          </div>
        </div>
      )}

      {state.serviceSelection.includes(ServiceSelection.BatteryReplacement) && (
        <div className="p-4 border border-slate-200 rounded-lg">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Battery Replacement Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 items-start">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Quantity</label>
                  <QuantityInput value={state.batteryReplacementQuantity} onChange={(v) => updateField('batteryReplacementQuantity', v)} />
              </div>
              <p className="text-lg font-semibold text-slate-700 self-center">Total: ₹{state.batteryReplacementTotalAmount.toFixed(2)}</p>
          </div>
          <div className="space-y-4">
            {state.batteryDetails.map((battery, index) => (
              <div key={battery.batteryId} className="p-4 bg-slate-50 rounded-lg border space-y-4">
                 <h4 className="font-semibold text-slate-700">Battery {index + 1}</h4>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input label="Serial Number" id={`batt-serial-${index}`} value={battery.serialNumber} onChange={e => handleUpdateBatteryDetail(index, 'serialNumber', e.target.value)} />
                    <Input label="Brand" id={`batt-brand-${index}`} value={battery.brand} onChange={e => handleUpdateBatteryDetail(index, 'brand', e.target.value)} />
                    <Input label="New Battery Amount (₹)" id={`batt-new-amt-${index}`} type="number" value={battery.newBatteryAmount} onChange={e => handleUpdateBatteryDetail(index, 'newBatteryAmount', parseFloat(e.target.value) || 0)} />
                    <Input label="Battery Exchange Value (₹)" id={`batt-exchange-${index}`} type="number" value={battery.exchangeValue} onChange={e => handleUpdateBatteryDetail(index, 'exchangeValue', parseFloat(e.target.value) || 0)} />
                 </div>
                 <p className="text-md font-semibold text-slate-600 text-right">Sub-total: ₹{(battery.newBatteryAmount - battery.exchangeValue).toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
