
import React, { useEffect, useMemo } from 'react';
import { Service, ServiceSelection } from '../types';
import { ADDON_PRICES } from '../constants';
import Button from './ui/Button';
import Card from './ui/Card';

interface PrintPreviewProps {
    service: Service;
    onClose: () => void;
}

interface PurchaseItem {
    description: string;
    qty: number;
    price: number;
}

const PurchaseSummaryView: React.FC<{ service: Service }> = ({ service }) => {
    const purchaseItems: PurchaseItem[] = useMemo(() => {
        const items: PurchaseItem[] = [];
        if (!service) return items;

        if (service.serviceSelection.includes(ServiceSelection.CarWashing) && service.carwashTotalAmount > 0) {
            items.push({
                description: `Car Washing ${service.isSubscription ? '(Subscription)' : ''}`,
                qty: service.carwashQuantity,
                price: service.carwashTotalAmount,
            });
        }
        if (service.serviceSelection.includes(ServiceSelection.TyreReplacement) && service.tyreReplacementTotalAmount > 0) {
            items.push({
                description: `Tyre Replacement`,
                qty: service.tyreReplacementQuantity,
                price: service.tyreReplacementTotalAmount
            });
        }
        if (service.serviceSelection.includes(ServiceSelection.BatteryReplacement)) {
            service.batteryDetails.forEach(battery => {
                const netAmount = (battery.newBatteryAmount || 0) - (battery.exchangeValue || 0);
                if (netAmount > 0) {
                    items.push({
                        description: `Battery: ${battery.brand || 'Unspecified Brand'}`,
                        qty: 1,
                        price: netAmount,
                    });
                }
            });
        }
        if (service.serviceSelection.includes(ServiceSelection.Addons)) {
            const predefined = [
                { k: 'standardWashQty', l: 'Standard Wash', p: ADDON_PRICES.standardWash },
                { k: 'interiorCleaningQty', l: 'Interior Cleaning', p: ADDON_PRICES.interiorCleaning },
                { k: 'premiumWashQty', l: 'Premium Wash', p: ADDON_PRICES.premiumWash },
                { k: 'waxServiceQty', l: 'Wax Service', p: ADDON_PRICES.waxService },
                { k: 'engineDetailingQty', l: 'Engine Detailing', p: ADDON_PRICES.engineDetailing },
                { k: 'wheelBalancingQty', l: 'Wheel Balancing', p: ADDON_PRICES.wheelBalancing },
            ];
            predefined.forEach(a => {
                const qty = service[a.k as keyof Service] as number;
                if (qty > 0) items.push({ description: a.l, qty: qty, price: qty * a.p });
            });
            service.categorizedAddons.forEach(ca => {
                if (ca.amount > 0 && ca.quantity > 0) {
                    items.push({ description: `${ca.productName} (${ca.category})`, qty: ca.quantity, price: ca.quantity * ca.amount });
                }
            });
        }
        
        service.customServices.forEach(custom => {
            if (custom.amount > 0) {
                items.push({
                    description: custom.serviceDescription || 'Custom Service',
                    qty: 1,
                    price: custom.amount,
                });
            }
        });

        return items;
    }, [service]);

    const DetailItem: React.FC<{ label: string; value: string | React.ReactNode }> = ({ label, value }) => (
      <div>
          <dt className="text-sm font-medium text-slate-500">{label}</dt>
          <dd className="text-base font-semibold text-slate-800">{value}</dd>
      </div>
    );

    return (
        <div className="space-y-8">
            <Card title="Customer Details" className="print:shadow-none print:border">
                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                    <DetailItem label="Name" value={`${service.customerFirstName} ${service.customerLastName}`} />
                    <DetailItem label="Mobile Number" value={service.mobileNumber} />
                    <DetailItem label="Car" value={`${service.carBrandModel} (${service.carNumber})`} />
                    <DetailItem label="Address" value={service.streetAddress} />
                </dl>
            </Card>

            <Card title="Purchase Summary" className="print:shadow-none print:border">
                <div className="flow-root">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-50">
                            <tr>
                                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-slate-900 sm:pl-6">Item / Service</th>
                                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-slate-900">Quantity</th>
                                <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-slate-900">Price</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 bg-white">
                            {purchaseItems.map((item, index) => (
                                <tr key={index}>
                                    <td className="w-full max-w-0 py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:w-auto sm:max-w-none sm:pl-6">{item.description}</td>
                                    <td className="px-3 py-4 text-sm text-center text-slate-500">{item.qty}</td>
                                    <td className="px-3 py-4 text-sm text-right text-slate-500">₹{item.price.toFixed(2)}</td>
                                </tr>
                            ))}
                            {purchaseItems.length === 0 && (
                                <tr>
                                    <td colSpan={3} className="text-center py-10 text-slate-500">No services or products selected.</td>
                                </tr>
                            )}
                        </tbody>
                        <tfoot>
                            <tr className="border-t-2 border-slate-300">
                                <th scope="row" colSpan={2} className="pl-4 pr-3 pt-4 text-right text-base font-semibold text-slate-900 sm:pl-6">Grand Total</th>
                                <td className="pl-3 pr-4 pt-4 text-right text-base font-semibold text-slate-900 sm:pr-6">₹{service.grandTotal.toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export const PrintPreview: React.FC<PrintPreviewProps> = ({ service, onClose }) => {
    useEffect(() => {
        window.print();
    }, []);

    return (
        <div className="bg-slate-200 p-4 sm:p-8">
            <div className="max-w-4xl mx-auto bg-white p-8 printable-area">
                <div className="flex justify-between items-center mb-8 no-print">
                    <h1 className="text-xl font-bold text-slate-800">Print Preview</h1>
                    <Button onClick={onClose} variant="secondary">Back to App</Button>
                </div>
                <PurchaseSummaryView service={service} />
            </div>
        </div>
    );
};
