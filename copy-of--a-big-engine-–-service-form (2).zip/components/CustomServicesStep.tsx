
import React from 'react';
import { Service, CustomService } from '../types';
import Input from './ui/Input';
import Button from './ui/Button';
import { IconPlus, IconTrash } from './ui/Icon';

interface Props {
  state: Service;
  dispatch: React.Dispatch<any>;
  updateField?: <K extends keyof Service>(field: K, value: Service[K]) => void;
  googleDriveUploadUrl?: string;
}

const CustomServicesStep: React.FC<Props> = ({ state, dispatch }) => {
  const handleAddService = () => {
    dispatch({ type: 'ADD_CUSTOM_SERVICE' });
  };

  const handleRemoveService = (index: number) => {
    dispatch({ type: 'REMOVE_CUSTOM_SERVICE', index });
  };

  const handleUpdateService = (index: number, field: keyof CustomService, value: any) => {
    dispatch({ type: 'UPDATE_CUSTOM_SERVICE', index, field, value });
  };
  
  return (
    <div className="space-y-4">
      {state.customServices.map((service, index) => (
        <div key={service.customServiceId} className="flex items-end space-x-2 p-3 bg-slate-50 rounded-lg">
          <Input
            label="Service Description"
            id={`custom-desc-${index}`}
            value={service.serviceDescription}
            onChange={(e) => handleUpdateService(index, 'serviceDescription', e.target.value)}
          />
          <Input
            label="Amount (₹)"
            id={`custom-amt-${index}`}
            type="number"
            value={service.amount}
            onChange={(e) => handleUpdateService(index, 'amount', parseFloat(e.target.value) || 0)}
            className="w-40"
          />
          <Button 
            variant="danger" 
            size="sm"
            onClick={() => handleRemoveService(index)} 
            className="p-2 h-10 w-10"
            aria-label={`Remove ${service.serviceDescription || 'custom service'}`}
          >
            <IconTrash className="w-5 h-5" />
          </Button>
        </div>
      ))}
      <div className="pt-2">
        <Button onClick={handleAddService} variant="ghost">
          <IconPlus className="w-5 h-5 mr-2" /> Add Custom Service
        </Button>
      </div>
       <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end items-center">
            <span className="text-lg font-bold text-slate-800">Custom Services Total: ₹{state.customServicesTotal.toFixed(2)}</span>
        </div>
    </div>
  );
};

export default CustomServicesStep;
