
import React, { useMemo } from 'react';
import { Service, ServiceSelection, ServiceStatus, User } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import { IconDownload } from './ui/Icon';

// Let TypeScript know that the XLSX object will be available globally from the CDN script
declare var XLSX: any;

interface MetricsReportProps {
  submissions: Service[];
  users: Omit<User, 'password'>[];
}

const MetricDisplay: React.FC<{ label: string; value: string | number; className?: string }> = ({ label, value, className }) => (
    <div className={`p-4 bg-slate-100 rounded-lg text-center ${className}`}>
        <p className="text-sm font-semibold text-slate-600 uppercase tracking-wider">{label}</p>
        <p className="text-3xl font-bold text-brand-blue">{value}</p>
    </div>
);

export const MetricsReport: React.FC<MetricsReportProps> = ({ submissions, users }) => {

    const metrics = useMemo(() => {
        const submittedServices = submissions.filter(s => s.status === ServiceStatus.Submitted);
        const totalRevenue = submittedServices.reduce((acc, s) => acc + s.grandTotal, 0);
        const serviceCounts = submittedServices.flatMap(s => s.serviceSelection).reduce((acc, service) => {
            acc[service] = (acc[service] || 0) + 1;
            return acc;
        }, {} as Record<ServiceSelection, number>);

        return {
            totalSubmissions: submissions.length,
            submittedCount: submittedServices.length,
            draftCount: submissions.length - submittedServices.length,
            totalRevenue: totalRevenue.toFixed(2),
            serviceCounts
        };
    }, [submissions]);

    const handleExportXlsx = () => {
        if (submissions.length === 0 && users.length === 0) {
            alert("No data to export.");
            return;
        }

        if (typeof XLSX === 'undefined') {
            alert("Error: The reporting library (SheetJS) could not be loaded. Please check your internet connection and refresh the page.");
            return;
        }
        
        const wb = XLSX.utils.book_new();
        const reportDate = new Date();
        const fileName = `full_service_report_${reportDate.toISOString().split('T')[0]}.xlsx`;

        // --- Create flattened data for each sheet ---
        const submissionsFlat = submissions.map(s => {
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const { tyreDetails, batteryDetails, customServices, categorizedAddons, ...rest } = s;
            return {
                ...rest,
                serviceSelection: s.serviceSelection.join(', '), // convert array to string for excel
            };
        });
        const tyreDetailsFlat = submissions.flatMap(s => s.tyreDetails);
        const batteryDetailsFlat = submissions.flatMap(s => s.batteryDetails);
        const customServicesFlat = submissions.flatMap(s => s.customServices);
        const categorizedAddonsFlat = submissions.flatMap(s => s.categorizedAddons);

        // --- Create a worksheet for each data type and add to workbook ---
        const ws_submissions = XLSX.utils.json_to_sheet(submissionsFlat);
        XLSX.utils.book_append_sheet(wb, ws_submissions, 'Submissions');
        
        const ws_users = XLSX.utils.json_to_sheet(users);
        XLSX.utils.book_append_sheet(wb, ws_users, 'Users');

        if (tyreDetailsFlat.length > 0) {
            const ws_tyres = XLSX.utils.json_to_sheet(tyreDetailsFlat);
            XLSX.utils.book_append_sheet(wb, ws_tyres, 'TyreDetails');
        }
        if (batteryDetailsFlat.length > 0) {
            const ws_batteries = XLSX.utils.json_to_sheet(batteryDetailsFlat);
            XLSX.utils.book_append_sheet(wb, ws_batteries, 'BatteryDetails');
        }
        if (customServicesFlat.length > 0) {
            const ws_custom = XLSX.utils.json_to_sheet(customServicesFlat);
            XLSX.utils.book_append_sheet(wb, ws_custom, 'CustomServices');
        }
        if (categorizedAddonsFlat.length > 0) {
            const ws_addons = XLSX.utils.json_to_sheet(categorizedAddonsFlat);
            XLSX.utils.book_append_sheet(wb, ws_addons, 'CategorizedAddons');
        }
        
        // --- Trigger the download ---
        XLSX.writeFile(wb, fileName);
    };

    return (
        <Card className="mb-8">
            <div className="flex flex-wrap gap-4 justify-between items-center mb-6">
                 <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Metrics & Reports</h2>
                 <Button onClick={handleExportXlsx} disabled={submissions.length === 0}>
                    <IconDownload className="w-5 h-5 mr-2" />
                    Export Full Report (Excel)
                </Button>
            </div>
           
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <MetricDisplay label="Total Services" value={metrics.totalSubmissions} />
                <MetricDisplay label="Submitted" value={metrics.submittedCount} />
                <MetricDisplay label="Drafts" value={metrics.draftCount} />
                <MetricDisplay label="Total Revenue" value={`₹${metrics.totalRevenue}`} />
            </div>

            {Object.keys(metrics.serviceCounts).length > 0 && (
                <div className="mt-6 pt-6 border-t border-slate-200">
                    <h3 className="text-lg font-semibold text-slate-700 mb-4">Submitted Service Breakdown</h3>
                    <div className="flex flex-wrap gap-4">
                        {Object.entries(metrics.serviceCounts).map(([service, count]) => (
                             <div key={service} className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg">
                                <span className="font-semibold">{service}:</span> {count}
                             </div>
                        ))}
                    </div>
                </div>
            )}
        </Card>
    );
};
