import React, { useState } from 'react';
import { Subscriber } from '../../types';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { IconPlus, IconUser, IconTrash } from '../ui/Icon';

interface SubscriberManagementPageProps {
    subscribers: Subscriber[];
    onUpdateSubscribers: (allSubscribers: Subscriber[]) => void;
}

export const SubscriberManagementPage: React.FC<SubscriberManagementPageProps> = ({ subscribers, onUpdateSubscribers }) => {
    const [newSubscriber, setNewSubscriber] = useState({ name: '', address: '', mobileNumber: '' });
    const [message, setMessage] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewSubscriber({ ...newSubscriber, [e.target.name]: e.target.value });
    };

    const handleAddSubscriber = (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        if (!newSubscriber.name || !newSubscriber.mobileNumber) {
            setMessage("Name and mobile number are required.");
            return;
        }
        
        const newSubscriberWithId: Subscriber = {
            id: `SUB-${Date.now()}`,
            ...newSubscriber
        };

        const updatedSubscribers = [...subscribers, newSubscriberWithId];
        onUpdateSubscribers(updatedSubscribers);

        setMessage(`Subscriber "${newSubscriber.name}" added successfully.`);
        setNewSubscriber({ name: '', address: '', mobileNumber: '' });

        setTimeout(() => setMessage(''), 3000);
    };

    const handleDeleteSubscriber = (id: string) => {
        if(window.confirm('Are you sure you want to delete this subscriber?')) {
            const updatedSubscribers = subscribers.filter(sub => sub.id !== id);
            onUpdateSubscribers(updatedSubscribers);
        }
    };

    return (
        <div className="space-y-8">
            <Card title="Add New Subscriber">
                <form onSubmit={handleAddSubscriber} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Input
                            label="Full Name"
                            id="name"
                            name="name"
                            value={newSubscriber.name}
                            onChange={handleInputChange}
                            required
                        />
                         <Input
                            label="Mobile Number"
                            id="mobileNumber"
                            name="mobileNumber"
                            type="tel"
                            value={newSubscriber.mobileNumber}
                            onChange={handleInputChange}
                            required
                        />
                         <Input
                            label="Address"
                            id="address"
                            name="address"
                            value={newSubscriber.address}
                            onChange={handleInputChange}
                        />
                    </div>
                    
                    {message && <p className={`text-sm text-center text-green-600`}>{message}</p>}
                    <div className="flex justify-end pt-2">
                        <Button type="submit">
                            <IconPlus className="w-5 h-5 mr-2" /> Add Subscriber
                        </Button>
                    </div>
                </form>
            </Card>

            <Card title="Existing Subscribers">
                <ul className="space-y-3">
                    {subscribers.length === 0 ? (
                        <p className="text-slate-500 text-center py-4">No subscribers found.</p>
                    ) : (
                        subscribers.map(subscriber => (
                            <li key={subscriber.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                               <div className="flex items-center space-x-3">
                                    <IconUser className="w-6 h-6 text-slate-500" />
                                    <div>
                                        <p className="font-semibold text-slate-800">{subscriber.name}</p>
                                        <p className="text-sm text-slate-600">{subscriber.mobileNumber}</p>
                                        <p className="text-xs text-slate-500">{subscriber.address}</p>
                                    </div>
                               </div>
                               <Button variant="danger" size="sm" onClick={() => handleDeleteSubscriber(subscriber.id)} className="p-2 h-9 w-9" aria-label={`Delete ${subscriber.name}`}>
                                  <IconTrash className="w-4 h-4" />
                               </Button>
                            </li>
                        ))
                    )}
                </ul>
            </Card>
        </div>
    )
};