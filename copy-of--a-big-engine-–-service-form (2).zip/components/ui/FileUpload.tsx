
import React, { useState, useRef } from 'react';
import Button from './Button';
import { IconCamera, IconVideoCamera, IconCheck, IconUpload } from './Icon';
import { uploadFileToDrive } from '../../services/fileUploadService';

interface FileUploadProps {
    label: string;
    fileUrl: string;
    onUpload: (url: string) => void;
    uploadType: 'photo' | 'video';
    carNumber: string;
    uploadUrl: string;
}

const FileUpload: React.FC<FileUploadProps> = ({ label, fileUrl, onUpload, uploadType, carNumber, uploadUrl }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const isPhoto = uploadType === 'photo';
    const Icon = isPhoto ? IconCamera : IconVideoCamera;
    const buttonText = fileUrl ? 'Change' : (isPhoto ? 'Upload Photo' : 'Upload Video');
    const acceptType = isPhoto ? 'image/*' : 'video/*';

    const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setIsLoading(true);
        setError(null);

        try {
            const url = await uploadFileToDrive(file, carNumber, uploadUrl);
            onUpload(url);
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError("An unknown error occurred.");
            }
        } finally {
            setIsLoading(false);
            // Reset file input to allow re-uploading the same file
            if(fileInputRef.current) {
                fileInputRef.current.value = "";
            }
        }
    };

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="text-center p-2 animate-pulse">
                    <IconUpload className="w-8 h-8 text-slate-500 mx-auto" />
                    <span className="text-xs text-slate-600 block">Uploading...</span>
                </div>
            );
        }
        if (fileUrl) {
             return (
                <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="text-center p-2 group" title="View uploaded file">
                    <IconCheck className="w-8 h-8 text-green-500 mx-auto transition-transform group-hover:scale-110" />
                    <span className="text-xs text-green-700 font-semibold block">Uploaded</span>
                </a>
            );
        }
        return <Icon className="w-8 h-8 text-slate-400" />;
    };

    return (
        <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
            <div className="mt-1 flex items-center space-x-4">
                <div className="w-24 h-24 bg-slate-200 rounded-lg flex items-center justify-center overflow-hidden">
                    {renderContent()}
                </div>
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    className="hidden"
                    accept={acceptType}
                    disabled={isLoading}
                />
                <Button variant="ghost" onClick={() => fileInputRef.current?.click()} disabled={isLoading}>
                    <Icon className="w-5 h-5 mr-2" /> {buttonText}
                </Button>
            </div>
            {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
        </div>
    );
};

export default FileUpload;
