
import React from 'react';
import { IconCloudCheck, IconDeviceFloppy, IconLoader, IconAlertTriangle, IconCloudOff } from './Icon';

export type SyncStatus = 'SYNCED' | 'UNSAVED' | 'SYNCING' | 'ERROR' | 'OFFLINE';

interface Props {
    status: SyncStatus;
    errorMessage?: string | null;
}

const SyncStatusIndicator: React.FC<Props> = ({ status, errorMessage }) => {
    const statusConfig = {
        SYNCED: { Icon: IconCloudCheck, color: 'text-green-500', tooltip: 'All changes saved to the cloud.', animate: false },
        UNSAVED: { Icon: IconDeviceFloppy, color: 'text-yellow-500', tooltip: 'You have unsaved changes.', animate: false },
        SYNCING: { Icon: IconLoader, color: 'text-blue-500', tooltip: 'Syncing with the cloud...', animate: true },
        ERROR: { Icon: IconAlertTriangle, color: 'text-red-500', tooltip: `Sync failed: ${errorMessage || 'Unknown error'}`, animate: false },
        OFFLINE: { Icon: IconCloudOff, color: 'text-slate-400', tooltip: 'Offline mode. Data is saved locally on this device.', animate: false },
    };

    if (!status) return null;

    const { Icon, color, tooltip, animate } = statusConfig[status];

    return (
        <div className="relative group flex items-center justify-center w-10 h-10" aria-live="polite" aria-label={`Sync status: ${status}`}>
            <Icon className={`w-6 h-6 ${color} ${animate ? 'animate-spin' : ''}`} />
            <div 
                role="tooltip"
                className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-max max-w-xs bg-slate-800 text-white text-xs font-semibold rounded py-1 px-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap"
            >
                {tooltip}
                <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-slate-800"></div>
            </div>
        </div>
    );
}

export default SyncStatusIndicator;
