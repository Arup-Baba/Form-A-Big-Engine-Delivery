
import React, { useState } from 'react';
import { Service, Customer } from '../types';
import Input from './ui/Input';
import Button from './ui/Button';
import { findCustomerByMobile } from '../services/customerService';

interface Props {
  state: Service;
  updateField: <K extends keyof Service>(field: K, value: Service[K]) => void;
  dispatch: React.Dispatch<any>;
  googleDriveUploadUrl?: string;
}

const CustomerDetailsStep: React.FC<Props> = ({ state, updateField, dispatch }) => {
  const [searchMobile, setSearchMobile] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchMessage, setSearchMessage] = useState('');

  const handleSearch = async () => {
    if (!searchMobile) {
      setSearchMessage('Please enter a mobile number to search.');
      return;
    }
    setIsSearching(true);
    setSearchMessage('');
    const customer = await findCustomerByMobile(searchMobile);
    setIsSearching(false);
    if (customer) {
      const customerData = {
        ...state,
        mobileNumber: customer.mobileNumber,
        customerFirstName: customer.firstName,
        customerLastName: customer.lastName,
        streetAddress: customer.streetAddress,
        carNumber: customer.carNumber,
        carBrandModel: customer.carBrandModel,
      };
      dispatch({ type: 'SET_FORM_DATA', payload: customerData });
      setSearchMessage('Customer data pre-filled successfully.');
    } else {
      setSearchMessage('No customer found with this mobile number.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="p-4 border border-slate-200 rounded-lg">
        <h3 className="font-semibold text-slate-700 mb-2">Search Existing Customer</h3>
        <div className="flex items-end space-x-2">
          <Input
            label="Search by Mobile Number"
            id="searchMobile"
            type="tel"
            value={searchMobile}
            onChange={(e) => setSearchMobile(e.target.value)}
          />
          <Button onClick={handleSearch} disabled={isSearching}>
            {isSearching ? 'Searching...' : 'Search'}
          </Button>
        </div>
        {searchMessage && <p className="mt-2 text-sm text-slate-600">{searchMessage}</p>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input
          label="Customer First Name"
          id="customerFirstName"
          value={state.customerFirstName}
          onChange={(e) => updateField('customerFirstName', e.target.value)}
        />
        <Input
          label="Customer Last Name"
          id="customerLastName"
          value={state.customerLastName}
          onChange={(e) => updateField('customerLastName', e.target.value)}
        />
        <Input
          label="Street Address"
          id="streetAddress"
          value={state.streetAddress}
          onChange={(e) => updateField('streetAddress', e.target.value)}
        />
        <Input
          label="Mobile Number"
          id="mobileNumber"
          type="tel"
          value={state.mobileNumber}
          onChange={(e) => updateField('mobileNumber', e.target.value)}
        />
        <Input
          label="Car Number"
          id="carNumber"
          value={state.carNumber}
          onChange={(e) => updateField('carNumber', e.target.value)}
        />
        <Input
          label="Car Brand & Model"
          id="carBrandModel"
          value={state.carBrandModel}
          onChange={(e) => updateField('carBrandModel', e.target.value)}
        />
      </div>
    </div>
  );
};

export default CustomerDetailsStep;
