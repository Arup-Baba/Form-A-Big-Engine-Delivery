
import React, { useState, useEffect } from 'react';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import { Settings } from '../types';

interface SettingsModalProps {
  initialSettings: Settings;
  onClose: () => void;
  onSave: (newSettings: Settings) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ initialSettings, onClose, onSave }) => {
  const [settings, setSettings] = useState<Settings>(initialSettings);
  const [saveMessage, setSaveMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setSettings(prev => ({...prev, [e.target.id]: e.target.value}));
  };

  const handleSave = () => {
    onSave(settings);
    setSaveMessage('Settings saved! Your changes are now live.');
    setTimeout(() => {
        setSaveMessage('');
        onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}>
        <Card title="Cloud & App Settings" className="w-full max-w-lg">
            <div className="space-y-6">
              <div>
                <p className="text-sm text-slate-600 mb-2">
                    Enter the Web App URL from your Google Apps Script. This is required for saving all app data (submissions, users, settings) to the cloud.
                </p>
                <Input
                    label="Cloud Data App URL (Google Sheets)"
                    id="googleSheetsUrl"
                    value={settings.googleSheetsUrl}
                    onChange={handleChange}
                    placeholder="URL for loading/saving all app data"
                />
              </div>
              <div className="pt-6 border-t border-slate-200">
                <p className="text-sm text-slate-600 mb-2">
                    Enter the URL for the script that handles file uploads to Google Drive.
                </p>
                <Input
                    label="Google Drive Upload URL"
                    id="googleDriveUploadUrl"
                    value={settings.googleDriveUploadUrl}
                    onChange={handleChange}
                    placeholder="URL for uploading files"
                />
              </div>
               <div className="pt-6 border-t border-slate-200">
                <p className="text-sm text-slate-600 mb-2">
                    Optionally, provide a URL for a custom logo.
                </p>
                <Input
                    label="Custom Logo URL"
                    id="customLogoUrl"
                    value={settings.customLogoUrl}
                    onChange={handleChange}
                    placeholder="https://example.com/logo.png"
                />
              </div>
            </div>
            {saveMessage && <p className="mt-4 text-sm text-green-600 font-semibold">{saveMessage}</p>}
            <div className="mt-6 flex justify-end space-x-3">
            <Button variant="ghost" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave}>Save Settings</Button>
            </div>
        </Card>
      </div>
    </div>
  );
};

export default SettingsModal;