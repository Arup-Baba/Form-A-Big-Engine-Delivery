import React, { useState } from 'react';
import Card from './ui/Card';
import Input from './ui/Input';
import Button from './ui/Button';
import { IconEngine } from './ui/Icon';

interface LoginPageProps {
    onLoginAttempt: (username: string, password?: string) => void;
    error: string;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginAttempt, error }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onLoginAttempt(username, password);
    };

    return (
        <div className="min-h-screen bg-slate-100 flex flex-col justify-center items-center p-4">
             <div className="flex items-center space-x-3 mb-8">
                <IconEngine className="w-12 h-12 text-brand-blue" />
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight uppercase">
                    <span className="text-brand-blue">A Big </span>
                    <span className="text-brand-accent">Engine</span>
                </h1>
            </div>
            <Card className="w-full max-w-md">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <h2 className="text-2xl font-bold text-center text-slate-800">Login</h2>
                    <Input 
                        label="Username" 
                        id="username"
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                        autoComplete="username"
                        required
                    />
                    <Input 
                        label="Password" 
                        id="password"
                        type="password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        autoComplete="current-password"
                        required
                    />
                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                    <Button type="submit" className="w-full">
                        Login
                    </Button>
                </form>
            </Card>
        </div>
    );
};

export default LoginPage;