
import React, { useMemo } from 'react';
import { Service, ServiceSelection } from '../types';
import Card from './ui/Card';
import { ADDON_PRICES } from '../constants';
import Button from './ui/Button';
import { IconPrint } from './ui/Icon';

interface Props {
  state: Service;
  updateField: <K extends keyof Service>(field: K, value: Service[K]) => void;
}

interface PurchaseItem {
    description: string;
    qty: number;
    price: number;
}

export const SummaryStep: React.FC<Props> = ({ state, updateField }) => {
  const purchaseItems: PurchaseItem[] = useMemo(() => {
    const items: PurchaseItem[] = [];

    // Car Washing Service
    if (state.serviceSelection.includes(ServiceSelection.CarWashing) && state.carwashTotalAmount > 0) {
        items.push({
            description: `Car Washing ${state.isSubscription ? '(Subscription)' : ''}`,
            qty: state.carwashQuantity,
            price: state.carwashTotalAmount,
        });
    }

    // Tyre Replacement Service (itemized)
    if (state.serviceSelection.includes(ServiceSelection.TyreReplacement)) {
        const pricePerTyre = state.tyreReplacementPrice || 0;
        if (pricePerTyre > 0 && state.tyreDetails.length > 0) {
             items.push({
                description: `Tyre Replacement`,
                qty: state.tyreReplacementQuantity,
                price: state.tyreReplacementTotalAmount
            });
        }
    }

    // Battery Replacement Service (itemized)
    if (state.serviceSelection.includes(ServiceSelection.BatteryReplacement)) {
        state.batteryDetails.forEach(battery => {
            const netAmount = (battery.newBatteryAmount || 0) - (battery.exchangeValue || 0);
            if (netAmount > 0) {
                items.push({
                    description: `Battery: ${battery.brand || 'Unspecified Brand'}`,
                    qty: 1,
                    price: netAmount,
                });
            }
        });
    }

    // Add-on Services and Products (itemized)
    if (state.serviceSelection.includes(ServiceSelection.Addons)) {
        const predefinedAddons = [
            { key: 'standardWashQty', label: 'Standard Wash', price: ADDON_PRICES.standardWash },
            { key: 'interiorCleaningQty', label: 'Interior Cleaning', price: ADDON_PRICES.interiorCleaning },
            { key: 'premiumWashQty', label: 'Premium Wash', price: ADDON_PRICES.premiumWash },
            { key: 'waxServiceQty', label: 'Wax Service', price: ADDON_PRICES.waxService },
            { key: 'engineDetailingQty', label: 'Engine Detailing', price: ADDON_PRICES.engineDetailing },
            { key: 'wheelBalancingQty', label: 'Wheel Balancing', price: ADDON_PRICES.wheelBalancing },
        ];

        predefinedAddons.forEach(addon => {
            const quantity = state[addon.key as keyof Service] as number;
            if (quantity > 0) {
                items.push({
                    description: addon.label,
                    qty: quantity,
                    price: quantity * addon.price,
                });
            }
        });

        state.categorizedAddons.forEach(addon => {
            if (addon.amount > 0 && addon.quantity > 0) {
                items.push({
                    description: `${addon.productName} (${addon.category})`,
                    qty: addon.quantity,
                    price: addon.quantity * addon.amount,
                });
            }
        });
    }

    // Custom Services (itemized)
    state.customServices.forEach(custom => {
        if (custom.amount > 0) {
            items.push({
                description: custom.serviceDescription || 'Custom Service',
                qty: 1,
                price: custom.amount,
            });
        }
    });

    return items;
  }, [state]);

  const DetailItem: React.FC<{ label: string; value: string | React.ReactNode }> = ({ label, value }) => (
      <div>
          <dt className="text-sm font-medium text-slate-500">{label}</dt>
          <dd className="text-base font-semibold text-slate-800">{value}</dd>
      </div>
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 printable-area">
      {/* Customer Details */}
      <Card title="Customer Details" className="print:shadow-none print:border">
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
              <DetailItem label="Name" value={`${state.customerFirstName} ${state.customerLastName}`} />
              <DetailItem label="Mobile Number" value={state.mobileNumber} />
              <DetailItem label="Car" value={`${state.carBrandModel} (${state.carNumber})`} />
              <DetailItem label="Address" value={state.streetAddress} />
          </dl>
      </Card>

      {/* Purchase Summary */}
      <Card title="Purchase Summary" className="print:shadow-none print:border relative">
          <div className="absolute top-4 right-4 no-print">
            <Button onClick={handlePrint} variant="ghost">
                <IconPrint className="w-5 h-5 mr-2" />
                Print Summary
            </Button>
          </div>
          <div className="flow-root">
              <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50">
                      <tr>
                          <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-slate-900 sm:pl-6">Item / Service</th>
                          <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-slate-900">Quantity</th>
                          <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-slate-900">Price</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                      {purchaseItems.map((item, index) => (
                          <tr key={index}>
                              <td className="w-full max-w-0 py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:w-auto sm:max-w-none sm:pl-6">{item.description}</td>
                              <td className="px-3 py-4 text-sm text-center text-slate-500">{item.qty}</td>
                              <td className="px-3 py-4 text-sm text-right text-slate-500">₹{item.price.toFixed(2)}</td>
                          </tr>
                      ))}
                      {purchaseItems.length === 0 && (
                          <tr>
                              <td colSpan={3} className="text-center py-10 text-slate-500">No services or products selected.</td>
                          </tr>
                      )}
                  </tbody>
                  <tfoot>
                      <tr className="border-t-2 border-slate-300">
                          <th scope="row" colSpan={2} className="pl-4 pr-3 pt-4 text-right text-base font-semibold text-slate-900 sm:pl-6">Grand Total</th>
                          <td className="pl-3 pr-4 pt-4 text-right text-base font-semibold text-slate-900 sm:pr-6">₹{state.grandTotal.toFixed(2)}</td>
                      </tr>
                  </tfoot>
              </table>
          </div>
      </Card>
      
      {/* Acknowledgement */}
      <div className="mt-6 no-print">
        <label className="flex items-start p-4 bg-yellow-50 border border-yellow-200 rounded-lg cursor-pointer hover:bg-yellow-100 transition-colors">
          <input
            type="checkbox"
            checked={state.acknowledgement}
            onChange={(e) => updateField('acknowledgement', e.target.checked)}
            className="h-5 w-5 rounded border-gray-300 text-brand-accent focus:ring-brand-accent mt-1 flex-shrink-0"
          />
          <span className="ml-3 text-sm text-yellow-800">
            I acknowledge that all the information entered is correct and have verified the details with the customer before final submission.
          </span>
        </label>
      </div>
    </div>
  );
};