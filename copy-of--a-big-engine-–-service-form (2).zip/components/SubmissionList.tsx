
import React, { useState } from 'react';
import { Service, ServiceStatus, ServiceSelection, User } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import { IconPencil, IconChevronDown } from './ui/Icon';
import { MetricsReport } from './MetricsReport';

interface SubmissionListProps {
  submissions: Service[];
  users: Omit<User, 'password'>[];
  onEdit: (service: Service) => void;
  onPrint: (service: Service) => void;
}

const DetailItem: React.FC<{ label: string; value?: string | number | null; children?: React.ReactNode }> = ({ label, value, children }) => {
    const displayValue = value ?? children;
    if (!displayValue && typeof displayValue !== 'number') return null;
    return (
        <div className="py-2 break-words">
            <dt className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</dt>
            <dd className="text-sm text-slate-800">{displayValue}</dd>
        </div>
    );
};

const ServiceDetailsView: React.FC<{ service: Service }> = ({ service }) => {
    return (
        <div className="space-y-4 text-sm">
            <h4 className="font-bold text-slate-700 mt-2 border-b pb-1">Full Details</h4>
            
            {service.serviceSelection.includes(ServiceSelection.CarWashing) && (
                <div>
                    <h5 className="font-semibold text-brand-blue mt-2">Car Washing</h5>
                    <dl className="grid grid-cols-2 md:grid-cols-3 gap-x-4">
                        <DetailItem label="Quantity" value={service.carwashQuantity} />
                        <DetailItem label="Is Subscription?" value={service.isSubscription ? 'Yes' : 'No'} />
                        <DetailItem label="Total" value={`₹${service.carwashTotalAmount.toFixed(2)}`} />
                    </dl>
                     <div className="mt-2 space-y-2">
                        <DetailItem label="Before Wash Photo" value={service.beforeWashingPhoto} />
                        <DetailItem label="Before Inventory Video" value={service.beforeVideoInventory} />
                        <DetailItem label="Before Top Body Video" value={service.beforeVideoTopBody} />
                        <DetailItem label="Before Underchassis Video" value={service.beforeVideoUnderchassis} />
                        <DetailItem label="After Wash Photo" value={service.afterWashingPhoto} />
                        <DetailItem label="After Interior Video" value={service.afterVideoInterior} />
                        <DetailItem label="After Exterior Video" value={service.afterVideoExterior} />
                        <DetailItem label="After Underchassis Video" value={service.afterVideoUnderchassis} />
                    </div>
                </div>
            )}

            {service.serviceSelection.includes(ServiceSelection.TyreReplacement) && service.tyreDetails.length > 0 && (
                <div>
                    <h5 className="font-semibold text-brand-blue mt-2">Tyre Replacement</h5>
                     {service.tyreDetails.map((tyre, index) => (
                        <div key={tyre.tyreId} className="p-2 mt-2 bg-slate-100 rounded-md border">
                           <p className="font-semibold text-xs text-slate-600">Tyre {index + 1}</p>
                           <dl className="grid grid-cols-2 md:grid-cols-4 gap-x-4">
                                <DetailItem label="DOT Code" value={tyre.dotCode} />
                                <DetailItem label="Tyre Size" value={tyre.tyreSize} />
                                <DetailItem label="Brand" value={tyre.brand} />
                                <DetailItem label="Model" value={tyre.model} />
                           </dl>
                           <DetailItem label="Serial Image" value={tyre.dotSerialNumberImage} />
                        </div>
                    ))}
                </div>
            )}
            
            {service.serviceSelection.includes(ServiceSelection.BatteryReplacement) && service.batteryDetails.length > 0 && (
                <div>
                    <h5 className="font-semibold text-brand-blue mt-2">Battery Replacement</h5>
                     {service.batteryDetails.map((battery, index) => (
                        <div key={battery.batteryId} className="p-2 mt-2 bg-slate-100 rounded-md border">
                           <p className="font-semibold text-xs text-slate-600">Battery {index + 1}</p>
                           <dl className="grid grid-cols-2 md:grid-cols-4 gap-x-4">
                                <DetailItem label="Serial #" value={battery.serialNumber} />
                                <DetailItem label="Brand" value={battery.brand} />
                                <DetailItem label="New Cost" value={`₹${battery.newBatteryAmount}`} />
                                <DetailItem label="Exchange Value" value={`₹${battery.exchangeValue}`} />
                           </dl>
                        </div>
                    ))}
                </div>
            )}

            {service.serviceSelection.includes(ServiceSelection.Addons) && (
                 <div>
                    <h5 className="font-semibold text-brand-blue mt-2">Add-ons</h5>
                     <dl className="grid grid-cols-2 md:grid-cols-4 gap-x-4">
                        <DetailItem label="Standard Wash" value={service.standardWashQty}/>
                        <DetailItem label="Interior Cleaning" value={service.interiorCleaningQty}/>
                        <DetailItem label="Premium Wash" value={service.premiumWashQty}/>
                        <DetailItem label="Wax Service" value={service.waxServiceQty}/>
                        <DetailItem label="Engine Detailing" value={service.engineDetailingQty}/>
                        <DetailItem label="Wheel Balancing" value={service.wheelBalancingQty}/>
                     </dl>
                    {service.categorizedAddons.length > 0 && (
                        <div className="mt-2">
                             {service.categorizedAddons.map((addon, index) => (
                                <div key={addon.id} className="p-2 mt-1 bg-slate-100 rounded-md border">
                                    <p className="font-semibold text-xs text-slate-600">Custom Add-on {index + 1}</p>
                                    <DetailItem label={`${addon.productName} (${addon.category})`} value={`Qty: ${addon.quantity} @ ₹${addon.amount}`} />
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
            
            {service.customServices.length > 0 && (
                 <div>
                    <h5 className="font-semibold text-brand-blue mt-2">Custom Services</h5>
                     {service.customServices.map((cs, index) => (
                        <div key={cs.customServiceId} className="p-2 mt-1 bg-slate-100 rounded-md border">
                            <DetailItem label={cs.serviceDescription || `Custom Service ${index+1}`} value={`₹${cs.amount}`} />
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};


export const SubmissionList: React.FC<SubmissionListProps> = ({ submissions, users, onEdit, onPrint }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  const handleToggleDetails = (id: string) => {
    setExpandedId(currentId => (currentId === id ? null : id));
  };
  
  const sortedSubmissions = [...submissions].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className="space-y-6">
       <MetricsReport submissions={submissions} users={users} />
       
       <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Service History</h2>

       {submissions.length === 0 ? (
          <Card className="text-center">
            <p className="text-slate-500 mt-2">No service history found.</p>
            <p className="text-slate-500 mt-1">Click "New Service" to create a request.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedSubmissions.map(service => (
              <Card key={service.submissionId} className="flex flex-col justify-between hover:shadow-xl transition-shadow duration-300">
                <div>
                  <div className="px-6 py-4 bg-slate-50 border-b border-slate-200">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-bold text-slate-800">{service.customerFirstName} {service.customerLastName}</h3>
                          <p className="text-sm text-slate-500">{service.carBrandModel} ({service.carNumber})</p>
                        </div>
                        <div className="flex flex-col items-end space-y-1 flex-shrink-0 ml-2">
                            <span className={`px-3 py-1 text-xs font-semibold rounded-full text-right ${service.status === ServiceStatus.Submitted ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {service.status}
                            </span>
                        </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="space-y-3 text-sm">
                      <p><strong className="font-semibold text-slate-600">Services:</strong> {service.serviceSelection.join(', ') || 'N/A'}</p>
                      <p><strong className="font-semibold text-slate-600">Submitted:</strong> {new Date(service.timestamp).toLocaleString()}</p>
                      <p><strong className="font-semibold text-slate-600">Total:</strong> <span className="text-xl font-bold text-slate-800">₹{service.grandTotal.toFixed(2)}</span></p>
                    </div>
                  </div>
                  <div className={`transition-all duration-500 ease-in-out overflow-hidden ${expandedId === service.submissionId ? 'max-h-[2000px]' : 'max-h-0'}`}>
                    <div className="px-6 pb-6">
                        <ServiceDetailsView service={service} />
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
                   <Button variant="ghost" onClick={() => handleToggleDetails(service.submissionId)} size="sm">
                       {expandedId === service.submissionId ? 'Hide Details' : 'View All Fields'}
                       <IconChevronDown className={`w-4 h-4 ml-2 transition-transform duration-300 ${expandedId === service.submissionId ? 'rotate-180' : ''}`} />
                   </Button>
                   <div className="flex items-center space-x-2">
                    {service.status === ServiceStatus.Draft && (
                        <Button variant="ghost" size="sm" onClick={() => onEdit(service)}>
                            <IconPencil className="w-4 h-4 mr-1"/> Edit
                        </Button>
                    )}
                    {service.status === ServiceStatus.Submitted && (
                        <>
                            <Button variant="secondary" size="sm" onClick={() => onPrint(service)}>Print</Button>
                        </>
                    )}
                   </div>
                </div>
              </Card>
            ))}
          </div>
       )}
    </div>
  );
};
