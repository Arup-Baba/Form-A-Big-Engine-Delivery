
import React from 'react';
import { Service, ServiceSelection } from '../types';
import { SERVICE_SELECTION_OPTIONS } from '../constants';

interface Props {
  state: Service;
  updateField: <K extends keyof Service>(field: K, value: Service[K]) => void;
  dispatch?: React.Dispatch<any>;
  googleDriveUploadUrl?: string;
}

const ServiceSelectionStep: React.FC<Props> = ({ state, updateField }) => {
  const handleToggle = (selection: ServiceSelection) => {
    const currentSelections = state.serviceSelection;
    const newSelections = currentSelections.includes(selection)
      ? currentSelections.filter(s => s !== selection)
      : [...currentSelections, selection];
    updateField('serviceSelection', newSelections);
  };

  return (
    <div>
      <p className="text-slate-600 mb-6">Select all services the customer requires. Details for each service will be collected in the next step.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {SERVICE_SELECTION_OPTIONS.map(option => {
          const isSelected = state.serviceSelection.includes(option);
          return (
            <button
              key={option}
              onClick={() => handleToggle(option)}
              className={`p-6 text-left rounded-lg border-2 transition-all duration-200 ${
                isSelected 
                ? 'bg-brand-accent/10 border-brand-accent ring-2 ring-brand-accent' 
                : 'bg-white border-slate-300 hover:border-brand-accent/70'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`font-semibold ${isSelected ? 'text-brand-blue' : 'text-slate-700'}`}>{option}</span>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 ${isSelected ? 'bg-brand-accent border-brand-accent' : 'border-slate-300'}`}>
                  {isSelected && (
                    <svg className="w-4 h-4 text-brand-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ServiceSelectionStep;
