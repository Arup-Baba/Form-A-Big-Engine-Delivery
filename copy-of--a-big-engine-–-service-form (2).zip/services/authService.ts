import { User } from '../types';

/**
 * Validates a user's credentials against a provided list of users.
 * This is a pure function and does not interact with localStorage.
 * @param username The username to validate.
 * @param password The password to validate.
 * @param users The complete list of users to check against.
 * @returns A user object without the password if valid, otherwise null.
 */
export const validateLogin = (username: string, password: string | undefined, users: User[]): User | null => {
    if (!password) return null;
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        // Return a "safe" user object without the password for the session
        const { password, ...userToReturn } = user;
        return userToReturn;
    }
    return null;
};

/**
 * Adds a new user to a list of users if the username doesn't already exist.
 * This is a pure function that returns a new state object.
 * @param newUser The user object to add.
 * @param currentUsers The existing list of users.
 * @returns An object indicating success or failure, with a message and the updated user list.
 */
export const addUser = (newUser: User, currentUsers: User[]): { success: boolean, message: string, updatedUsers?: User[] } => {
    if (currentUsers.find(u => u.username === newUser.username)) {
        return { success: false, message: 'Username already exists.' };
    }
    const updatedUsers = [...currentUsers, newUser];
    return { success: true, message: 'User created successfully.', updatedUsers };
};
