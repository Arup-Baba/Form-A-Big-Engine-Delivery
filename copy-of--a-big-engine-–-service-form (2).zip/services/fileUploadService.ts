
/**
 * Reads a file and converts it to a base64 encoded data URL.
 * @param {File} file - The file to read.
 * @returns {Promise<string>} The base64 data URL.
 */
const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

/**
 * Uploads a file to the configured Google Drive endpoint, specifying a subfolder.
 *
 * @param {File} file - The file to upload.
 * @param {string} subFolderName - The name of the subfolder (car number) to upload into.
 * @param {string} uploadUrl - The destination URL for the upload script.
 * @returns {Promise<string>} The URL of the uploaded file.
 * @throws {Error} If the upload URL is not provided or if the upload fails.
 */
export const uploadFileToDrive = async (file: File, subFolderName: string, uploadUrl: string): Promise<string> => {
  console.log(`Starting upload for: ${file.name} into folder: ${subFolderName}`);
  
  if (!uploadUrl) {
    throw new Error("Google Drive Upload URL is not configured. Please set it in Settings.");
  }

  if (!subFolderName || subFolderName.trim() === '') {
    throw new Error("Cannot upload: Car Number is required to create a folder. Please enter a Car Number first.");
  }

  const base64 = await toBase64(file);

  const payload = {
    filename: file.name,
    mimeType: file.type,
    base64: base64,
    subFolderName: subFolderName
  };

  try {
    const response = await fetch(uploadUrl, {
      mode: 'cors',
      method: 'POST',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'text/plain;charset=utf-8', // Required by Apps Script
      },
    });

    if (response.ok) {
        const result = await response.json();
        if (result.status === 'success' && result.url) {
            console.log(`Successfully uploaded ${result.name}. URL: ${result.url}`);
            return result.url;
        } else {
            throw new Error(result.message || 'The upload script returned an unknown error.');
        }
    } else {
        // Handle non-200 responses, which might not be JSON
        const errorText = await response.text();
        try {
            const errorJson = JSON.parse(errorText);
            throw new Error(errorJson.message || `Upload failed with status: ${response.status}`);
        } catch (e) {
            // The error response wasn't JSON, likely an HTML error page from Apps Script
            throw new Error(`Upload failed. Server response: ${errorText.substring(0, 200)}...`);
        }
    }
  } catch (error) {
    console.error("Error during file upload:", error);
    if (error instanceof Error) {
        if (error.message.includes('not configured') || error.message.includes('Car Number is required')) throw error;
        // Check for a generic network failure
        if (error.name === 'TypeError') { // 'Failed to fetch' is a TypeError
             throw new Error('A network error occurred. Check your connection, CORS settings, and the endpoint URL.');
        }
        throw error; // Re-throw the already descriptive error
    }
    throw new Error('An unknown error occurred during file upload.');
  }
};
