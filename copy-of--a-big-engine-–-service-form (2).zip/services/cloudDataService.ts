
import { AppData, User, Settings, Service, ServiceSelection, TyreDetail, BatteryDetail, CustomService, CategorizedAddon, Subscriber } from '../types';

// The default state for a new application or when no data is found
const getDefaultAppData = (): AppData => {
    const initialAdminUser: User = { username: 'admin', password: 'admin@123', role: 'admin' };
    return {
        submissions: [],
        users: [initialAdminUser],
        subscribers: [],
        settings: {
            googleSheetsUrl: localStorage.getItem('googleSheetsUrl') || '',
            googleDriveUploadUrl: localStorage.getItem('googleDriveUploadUrl') || '',
            customLogoUrl: localStorage.getItem('customLogoUrl') || '',
        }
    };
};

/**
 * Loads the entire application state from the cloud, which is structured as a relational database.
 * It fetches multiple "tables" (sheets) and re-hydrates the data into the nested structure the app uses.
 */
export const loadAppData = async (): Promise<AppData> => {
    const sheetsUrl = localStorage.getItem('googleSheetsUrl');
    if (!sheetsUrl) {
        console.log("Cloud URL not set. Using default initial data.");
        return getDefaultAppData();
    }

    console.log("Fetching relational data from cloud backend...");
    try {
        const url = new URL(sheetsUrl);
        url.searchParams.set('action', 'loadAllData');

        const response = await fetch(url.toString(), {
            method: 'GET',
            mode: 'cors',
            headers: { 'Content-Type': 'application/json' },
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Failed to fetch. Server responded with status: ${response.status}. Response: ${errorText}`);
        }
        
        const result = await response.json();
        if (result.status !== 'success') {
             throw new Error(result.message || 'Cloud script returned an error.');
        }

        console.log("Successfully loaded flat data from cloud. Re-hydrating...");
        
        // --- RE-HYDRATION ---
        const flatData = result.data;
        
        // First, parse all child tables with correct types
        const tyreDetails = (flatData.TyreDetails || []).map((d: any): TyreDetail => ({ ...d })); // All strings
        const batteryDetails = (flatData.BatteryDetails || []).map((d: any): BatteryDetail => ({ 
            ...d, 
            exchangeValue: parseFloat(d.exchangeValue) || 0, 
            newBatteryAmount: parseFloat(d.newBatteryAmount) || 0 
        }));
        const customServices = (flatData.CustomServices || []).map((d: any): CustomService => ({
             ...d, 
             amount: parseFloat(d.amount) || 0 
        }));
        const categorizedAddons = (flatData.CategorizedAddons || []).map((d: any): CategorizedAddon => ({
            ...d,
            quantity: parseInt(d.quantity, 10) || 0,
            amount: parseFloat(d.amount) || 0
        }));

        // Now, parse submissions and nest the typed child data
        const submissions: Service[] = (flatData.Submissions || []).map((sub: any): Service => ({
            ...sub,
            // Booleans
            isSubscription: sub.isSubscription === 'TRUE' || sub.isSubscription === true,
            acknowledgement: sub.acknowledgement === 'TRUE' || sub.acknowledgement === true,
            // Numbers
            carwashQuantity: parseInt(sub.carwashQuantity, 10) || 0,
            carWashPrice: parseFloat(sub.carWashPrice) || 0,
            carwashTotalAmount: parseFloat(sub.carwashTotalAmount) || 0,
            tyreReplacementQuantity: parseInt(sub.tyreReplacementQuantity, 10) || 0,
            tyreReplacementPrice: parseFloat(sub.tyreReplacementPrice) || 0,
            tyreReplacementTotalAmount: parseFloat(sub.tyreReplacementTotalAmount) || 0,
            batteryReplacementQuantity: parseInt(sub.batteryReplacementQuantity, 10) || 0,
            batteryReplacementTotalAmount: parseFloat(sub.batteryReplacementTotalAmount) || 0,
            standardWashQty: parseInt(sub.standardWashQty, 10) || 0,
            interiorCleaningQty: parseInt(sub.interiorCleaningQty, 10) || 0,
            premiumWashQty: parseInt(sub.premiumWashQty, 10) || 0,
            waxServiceQty: parseInt(sub.waxServiceQty, 10) || 0,
            engineDetailingQty: parseInt(sub.engineDetailingQty, 10) || 0,
            wheelBalancingQty: parseInt(sub.wheelBalancingQty, 10) || 0,
            addonsTotal: parseFloat(sub.addonsTotal) || 0,
            categorizedAddonsTotal: parseFloat(sub.categorizedAddonsTotal) || 0,
            customServicesTotal: parseFloat(sub.customServicesTotal) || 0,
            grandTotal: parseFloat(sub.grandTotal) || 0,
            // Re-nest child tables
            tyreDetails: tyreDetails.filter((d: TyreDetail) => d.relatedServiceId === sub.submissionId),
            batteryDetails: batteryDetails.filter((d: BatteryDetail) => d.relatedServiceId === sub.submissionId),
            customServices: customServices.filter((d: CustomService) => d.relatedServiceId === sub.submissionId),
            categorizedAddons: categorizedAddons.filter((d: CategorizedAddon) => d.relatedServiceId === sub.submissionId),
            // Convert comma-separated string back to array
            serviceSelection: sub.serviceSelection ? sub.serviceSelection.split(',') : [],
        }));

        const settings = (flatData.Settings || [])[0] || getDefaultAppData().settings;
        const users = (flatData.Users || []).length > 0 ? flatData.Users : getDefaultAppData().users;
        const subscribers = (flatData.Subscribers || []).map((d: any): Subscriber => ({ ...d }));

        return { submissions, users, settings, subscribers };
        
    } catch (error) {
        console.error("Critical error loading data from cloud backend. Could not complete request.", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
        alert(`Error loading data from cloud backend. Please check settings, deployment, and network connection. Using default data as fallback. Details: ${errorMessage}`);
        return getDefaultAppData();
    }
};

/**
 * Saves the entire application state to the cloud by flattening the data into a relational format.
 */
export const saveAppData = async (data: AppData): Promise<void> => {
    const sheetsUrl = data.settings.googleSheetsUrl;
    if (!sheetsUrl) {
        console.log("Cloud URL not set. Cannot save data.");
        return;
    }

    console.log("Flattening data for relational save...");

    // --- FLATTENING ---
    const submissionsFlat: any[] = [];
    const tyreDetailsFlat: any[] = [];
    const batteryDetailsFlat: any[] = [];
    const customServicesFlat: any[] = [];
    const categorizedAddonsFlat: any[] = [];

    data.submissions.forEach(service => {
        const { tyreDetails, batteryDetails, customServices, categorizedAddons, ...mainSubmission } = service;
        
        submissionsFlat.push({
            ...mainSubmission,
            serviceSelection: service.serviceSelection.join(','), // Convert array to comma-separated string
        });

        if (tyreDetails) tyreDetailsFlat.push(...tyreDetails);
        if (batteryDetails) batteryDetailsFlat.push(...batteryDetails);
        if (customServices) customServicesFlat.push(...customServices);
        if (categorizedAddons) categorizedAddonsFlat.push(...categorizedAddons);
    });

    const payload = {
        action: 'saveAllData',
        payload: {
            Submissions: submissionsFlat,
            TyreDetails: tyreDetailsFlat,
            BatteryDetails: batteryDetailsFlat,
            CustomServices: customServicesFlat,
            CategorizedAddons: categorizedAddonsFlat,
            Users: data.users,
            Subscribers: data.subscribers,
            Settings: [data.settings], // Send as array of one for consistency with load
        }
    };
    
    console.log("Saving flattened data to backend...");
    try {
        const response = await fetch(sheetsUrl, {
            mode: 'cors',
            method: 'POST',
            body: JSON.stringify(payload),
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        });

        if (!response.ok) {
             const errorText = await response.text();
            throw new Error(`Save failed. Server responded with status: ${response.status}. Response: ${errorText}`);
        }

        const result = await response.json();
        if (result.status !== 'success') {
            throw new Error(result.message || 'An unknown error occurred during save.');
        }
        console.log("Successfully saved relational data to cloud.");
    } catch (error) {
        console.error("Error saving data to cloud backend:", error);
         if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
             throw new Error('A network error occurred while saving. Please check the URL and your connection.');
        }
        throw error;
    }
};