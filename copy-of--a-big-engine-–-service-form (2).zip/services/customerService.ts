
import { MOCK_CUSTOMERS } from '../constants';
import { Customer } from '../types';

export const findCustomerByMobile = async (mobileNumber: string): Promise<Customer | null> => {
  console.log(`Searching for customer with mobile: ${mobileNumber}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      const customer = MOCK_CUSTOMERS.find(c => c.mobileNumber === mobileNumber) || null;
      resolve(customer);
    }, 500);
  });
};
