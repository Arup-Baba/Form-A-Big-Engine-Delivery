import { useReducer, useMemo, useCallback, useEffect } from 'react';
import { Service, ServiceStatus, ServiceSelection, TyreDetail, BatteryDetail, CustomService, CategorizedAddon } from '../types';
import { ADDON_PRICES, SERVICE_PRICES, ADDON_CATEGORIES } from '../constants';

type FormAction =
  | { type: 'UPDATE_FIELD'; field: keyof Service; value: any }
  | { type: 'SET_FORM_DATA'; payload: Service }
  | { type: 'ADD_TYRE_DETAIL' }
  | { type: 'REMOVE_TYRE_DETAIL'; index: number }
  | { type: 'UPDATE_TYRE_DETAIL'; index: number; field: keyof TyreDetail; value: any }
  | { type: 'ADD_BATTERY_DETAIL' }
  | { type: 'REMOVE_BATTERY_DETAIL'; index: number }
  | { type: 'UPDATE_BATTERY_DETAIL'; index: number; field: keyof BatteryDetail; value: any }
  | { type: 'ADD_CUSTOM_SERVICE' }
  | { type: 'REMOVE_CUSTOM_SERVICE'; index: number }
  | { type: 'UPDATE_CUSTOM_SERVICE'; index: number; field: keyof CustomService; value: any }
  | { type: 'ADD_CATEGORIZED_ADDON' }
  | { type: 'REMOVE_CATEGORIZED_ADDON'; index: number }
  | { type: 'UPDATE_CATEGORIZED_ADDON'; index: number; field: keyof CategorizedAddon; value: any };

const createInitialState = (initialService?: Service | null): Service => {
  if (initialService) return initialService;

  const submissionId = `SUB-${Date.now()}`;
  return {
    submissionId,
    timestamp: new Date().toISOString(),
    customerFirstName: '',
    customerLastName: '',
    streetAddress: '',
    mobileNumber: '',
    carNumber: '',
    carBrandModel: '',
    serviceSelection: [],
    
    isSubscription: false,
    carwashQuantity: 0,
    carWashPrice: SERVICE_PRICES.carWashBase,
    carwashTotalAmount: 0,
    beforeWashingPhoto: '',
    beforeVideoInventory: '',
    beforeVideoTopBody: '',
    beforeVideoUnderchassis: '',
    afterWashingPhoto: '',
    afterVideoInterior: '',
    afterVideoExterior: '',
    afterVideoUnderchassis: '',

    tyreReplacementQuantity: 0,
    tyreReplacementPrice: SERVICE_PRICES.tyreReplacement,
    tyreReplacementTotalAmount: 0,
    tyreDetails: [],

    batteryReplacementQuantity: 0,
    batteryReplacementTotalAmount: 0,
    batteryDetails: [],

    standardWashQty: 0,
    interiorCleaningQty: 0,
    premiumWashQty: 0,
    waxServiceQty: 0,
    engineDetailingQty: 0,
    wheelBalancingQty: 0,
    addonsTotal: 0,
    
    categorizedAddons: [],
    categorizedAddonsTotal: 0,
    
    customServices: [],
    customServicesTotal: 0,
    
    grandTotal: 0,
    acknowledgement: false,
    status: ServiceStatus.Draft,
  };
};

const formReducer = (state: Service, action: FormAction): Service => {
  switch (action.type) {
    case 'UPDATE_FIELD':
      return { ...state, [action.field]: action.value };
    case 'SET_FORM_DATA':
      return action.payload;
    case 'ADD_TYRE_DETAIL':
      return { ...state, tyreDetails: [...state.tyreDetails, { tyreId: `T-${Date.now()}`, relatedServiceId: state.submissionId, dotCode: '', dotSerialNumberImage: '', tyreSize: '', brand: '', model: '' }] };
    case 'REMOVE_TYRE_DETAIL':
      return { ...state, tyreDetails: state.tyreDetails.filter((_, i) => i !== action.index) };
    case 'UPDATE_TYRE_DETAIL':
        {
            const newTyreDetails = [...state.tyreDetails];
            (newTyreDetails[action.index] as any)[action.field] = action.value;
            return { ...state, tyreDetails: newTyreDetails };
        }
    case 'ADD_BATTERY_DETAIL':
      return { ...state, batteryDetails: [...state.batteryDetails, { batteryId: `B-${Date.now()}`, relatedServiceId: state.submissionId, serialNumber: '', brand: '', exchangeValue: 0, newBatteryAmount: 0 }] };
    case 'REMOVE_BATTERY_DETAIL':
      return { ...state, batteryDetails: state.batteryDetails.filter((_, i) => i !== action.index) };
    case 'UPDATE_BATTERY_DETAIL':
        {
            const newBatteryDetails = [...state.batteryDetails];
            (newBatteryDetails[action.index] as any)[action.field] = action.value;
            return { ...state, batteryDetails: newBatteryDetails };
        }
    case 'ADD_CUSTOM_SERVICE':
        return { ...state, customServices: [...state.customServices, { customServiceId: `CS-${Date.now()}`, relatedServiceId: state.submissionId, serviceDescription: '', amount: 0 }] };
    case 'REMOVE_CUSTOM_SERVICE':
        return { ...state, customServices: state.customServices.filter((_, i) => i !== action.index) };
    case 'UPDATE_CUSTOM_SERVICE':
        {
            const newCustomServices = [...state.customServices];
            (newCustomServices[action.index] as any)[action.field] = action.value;
            return { ...state, customServices: newCustomServices };
        }
    case 'ADD_CATEGORIZED_ADDON':
        return { ...state, categorizedAddons: [...state.categorizedAddons, { id: `CA-${Date.now()}`, relatedServiceId: state.submissionId, category: ADDON_CATEGORIES[0], productName: '', quantity: 1, amount: 0 }] };
    case 'REMOVE_CATEGORIZED_ADDON':
        return { ...state, categorizedAddons: state.categorizedAddons.filter((_, i) => i !== action.index) };
    case 'UPDATE_CATEGORIZED_ADDON':
        {
            const newCategorizedAddons = [...state.categorizedAddons];
            (newCategorizedAddons[action.index] as any)[action.field] = action.value;
            return { ...state, categorizedAddons: newCategorizedAddons };
        }
    default:
      return state;
  }
};

export const useServiceForm = (initialService?: Service | null) => {
  const [state, dispatch] = useReducer(formReducer, createInitialState(initialService));

  const updateField = useCallback(<K extends keyof Service>(field: K, value: Service[K]) => {
    dispatch({ type: 'UPDATE_FIELD', field, value });
  }, []);

  // Recalculate totals whenever relevant quantities change
  useEffect(() => {
    const basePrice = state.carWashPrice || 0;
    const price = state.isSubscription 
      ? basePrice * (1 - SERVICE_PRICES.carWashSubscriptionDiscount)
      : basePrice;
    const carwashTotal = state.carwashQuantity * price;
    updateField('carwashTotalAmount', carwashTotal);
  }, [state.carwashQuantity, state.isSubscription, state.carWashPrice, updateField]);

  useEffect(() => {
    const tyreTotal = state.tyreReplacementQuantity * (state.tyreReplacementPrice || 0);
    updateField('tyreReplacementTotalAmount', tyreTotal);
  }, [state.tyreReplacementQuantity, state.tyreReplacementPrice, updateField]);

  useEffect(() => {
    const batteryTotal = state.batteryDetails.reduce((total, battery) => {
      return total + ((battery.newBatteryAmount || 0) - (battery.exchangeValue || 0));
    }, 0);
    updateField('batteryReplacementTotalAmount', batteryTotal);
  }, [state.batteryDetails, updateField]);


  useEffect(() => {
    const customAddonsTotal = state.categorizedAddons.reduce((sum, addon) => {
        return sum + ((addon.quantity || 0) * (addon.amount || 0));
    }, 0);
    updateField('categorizedAddonsTotal', customAddonsTotal);
  }, [state.categorizedAddons, updateField]);


  useEffect(() => {
    const predefinedTotal = (state.standardWashQty * ADDON_PRICES.standardWash) +
                        (state.interiorCleaningQty * ADDON_PRICES.interiorCleaning) +
                        (state.premiumWashQty * ADDON_PRICES.premiumWash) +
                        (state.waxServiceQty * ADDON_PRICES.waxService) +
                        (state.engineDetailingQty * ADDON_PRICES.engineDetailing) +
                        (state.wheelBalancingQty * ADDON_PRICES.wheelBalancing);
    updateField('addonsTotal', predefinedTotal + state.categorizedAddonsTotal);
  }, [
      state.standardWashQty, 
      state.interiorCleaningQty, 
      state.premiumWashQty, 
      state.waxServiceQty, 
      state.engineDetailingQty, 
      state.wheelBalancingQty,
      state.categorizedAddonsTotal,
      updateField
    ]);

  useEffect(() => {
    const customServicesTotal = state.customServices.reduce((sum, service) => sum + Number(service.amount || 0), 0);
    updateField('customServicesTotal', customServicesTotal);
  }, [state.customServices, updateField]);
  
  // Grand Total Calculation
  const grandTotal = useMemo(() => {
    let total = 0;
    if (state.serviceSelection.includes(ServiceSelection.CarWashing)) total += state.carwashTotalAmount;
    if (state.serviceSelection.includes(ServiceSelection.TyreReplacement)) total += state.tyreReplacementTotalAmount;
    if (state.serviceSelection.includes(ServiceSelection.BatteryReplacement)) total += state.batteryReplacementTotalAmount;
    if (state.serviceSelection.includes(ServiceSelection.Addons)) total += state.addonsTotal;
    total += state.customServicesTotal;
    return total;
  }, [state.serviceSelection, state.carwashTotalAmount, state.tyreReplacementTotalAmount, state.batteryReplacementTotalAmount, state.addonsTotal, state.customServicesTotal]);

  useEffect(() => {
      updateField('grandTotal', grandTotal);
  }, [grandTotal, updateField]);

  // Sync child table rows with quantity
  useEffect(() => {
    if (!state.serviceSelection.includes(ServiceSelection.TyreReplacement)) return;
    const diff = state.tyreReplacementQuantity - state.tyreDetails.length;
    if (diff > 0) {
      for (let i = 0; i < diff; i++) dispatch({ type: 'ADD_TYRE_DETAIL' });
    } else if (diff < 0) {
      for (let i = 0; i < -diff; i++) dispatch({ type: 'REMOVE_TYRE_DETAIL', index: state.tyreDetails.length - 1 - i });
    }
  }, [state.tyreReplacementQuantity, state.tyreDetails.length, state.serviceSelection]);

  useEffect(() => {
    if (!state.serviceSelection.includes(ServiceSelection.BatteryReplacement)) return;
    const diff = state.batteryReplacementQuantity - state.batteryDetails.length;
    if (diff > 0) {
      for (let i = 0; i < diff; i++) dispatch({ type: 'ADD_BATTERY_DETAIL' });
    } else if (diff < 0) {
      for (let i = 0; i < -diff; i++) dispatch({ type: 'REMOVE_BATTERY_DETAIL', index: state.batteryDetails.length - 1 - i });
    }
  }, [state.batteryReplacementQuantity, state.batteryDetails.length, state.serviceSelection]);

  return { state, dispatch, updateField };
};